# Gestor Fornecedores — Android

Projeto Android offline para gerenciamento de fornecedores e servidores.

Inclui:
- Fornecedores: cadastrar, editar e excluir
- Servidores: cadastrar, editar e excluir
- Valores
- Dashboard
- SQLite local
- Sem login
- Sem módulo de vencimentos

## Gerar APK
Abra o projeto em um ambiente Android/IDE que suporte Gradle e Android SDK.
Execute:
./gradlew assembleDebug

O APK será gerado em:
app/build/outputs/apk/debug/app-debug.apk

Nome do aplicativo: Gestor Fornecedores
Package: br.com.gestorfornecedores
