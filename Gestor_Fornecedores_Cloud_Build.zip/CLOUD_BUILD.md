# Gestor Fornecedores — compilação na nuvem

Este projeto foi preparado para gerar o APK usando **GitHub Actions**.
Você não precisa instalar Android SDK no celular.

## Como gerar o APK pelo celular

1. Crie uma conta no GitHub, se ainda não tiver.
2. Crie um repositório novo, por exemplo:
   `gestor-fornecedores`
3. Envie **todos os arquivos deste projeto** para o repositório.
4. Abra a aba **Actions**.
5. Selecione **Gerar APK - Gestor Fornecedores**.
6. Toque em **Run workflow**.
7. Aguarde a compilação terminar.
8. Abra a execução concluída e procure **Artifacts**.
9. Baixe `Gestor-Fornecedores-APK`.
10. Dentro do ZIP estará `app-debug.apk`.

## O que a nuvem faz

O GitHub Actions usa uma máquina virtual com:
- Java 17
- Android SDK
- Build Tools
- Gradle 8.9

O APK é gerado no servidor e disponibilizado como artefato para download.

## Observação

O APK é uma versão de teste/debug. Para publicar na Google Play, será necessário configurar assinatura de release e preparar os arquivos da Play Store.
