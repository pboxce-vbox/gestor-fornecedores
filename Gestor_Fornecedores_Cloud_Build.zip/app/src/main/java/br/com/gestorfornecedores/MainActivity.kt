package br.com.gestorfornecedores

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DB(context: Context) : SQLiteOpenHelper(context, "gestor.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE fornecedores(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, telefone TEXT, observacoes TEXT)")
        db.execSQL("CREATE TABLE servidores(id INTEGER PRIMARY KEY AUTOINCREMENT, fornecedor_id INTEGER, nome TEXT NOT NULL, endereco TEXT, usuario TEXT, senha TEXT, valor REAL DEFAULT 0, observacoes TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

class MainActivity : Activity() {
    lateinit var db: DB
    lateinit var content: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = DB(this)
        showHome()
    }

    fun base(title: String): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(24,24,24,24)
        val bar = TextView(this)
        bar.text = title
        bar.textSize = 24f
        bar.setTextColor(Color.WHITE)
        bar.setPadding(20,20,20,20)
        bar.setBackgroundColor(Color.rgb(21,101,192))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0,20,0,0)
        root.addView(content, LinearLayout.LayoutParams(-1,0,1f))
        return root
    }

    fun button(text:String, action:()->Unit): Button {
        val b=Button(this); b.text=text; b.setOnClickListener{action()}; return b
    }

    fun showHome() {
        val root=base("Gestor Fornecedores")
        val f=count("fornecedores"); val s=count("servidores")
        content.addView(label("Fornecedores cadastrados: $f"))
        content.addView(label("Servidores cadastrados: $s"))
        content.addView(button("👥 Fornecedores"){showFornecedores()})
        content.addView(button("🖥️ Servidores"){showServidores()})
        content.addView(button("💰 Resumo de valores"){showResumo()})
        content.addView(button("💾 Backup dos dados"){backup()})
        setContentView(root)
    }

    fun label(t:String):TextView { val v=TextView(this); v.text=t; v.textSize=18f; v.setPadding(8,12,8,12); return v }
    fun count(table:String)=db.readableDatabase.rawQuery("SELECT COUNT(*) FROM $table",null).use{it.moveToFirst();it.getInt(0)}

    fun showFornecedores() {
        val root=base("Fornecedores")
        content.addView(button("➕ Cadastrar fornecedor"){formFornecedor(null)})
        val c=db.readableDatabase.rawQuery("SELECT id,nome,telefone FROM fornecedores ORDER BY nome",null)
        while(c.moveToNext()){
            val id=c.getInt(0); val row=LinearLayout(this); row.orientation=LinearLayout.VERTICAL
            row.addView(label(c.getString(1)+"\n"+(c.getString(2)?:"")))
            row.addView(button("✏️ Editar"){formFornecedor(id)})
            row.addView(button("🗑️ Excluir"){deleteFornecedor(id)})
            content.addView(row)
        }
        c.close(); content.addView(button("← Voltar"){showHome()}); setContentView(root)
    }

    fun formFornecedor(id:Int?) {
        val root=base(if(id==null)"Novo fornecedor" else "Editar fornecedor")
        val nome=EditText(this); nome.hint="Nome do fornecedor"
        val tel=EditText(this); tel.hint="WhatsApp / telefone"
        val obs=EditText(this); obs.hint="Observações"
        if(id!=null) db.readableDatabase.rawQuery("SELECT nome,telefone,observacoes FROM fornecedores WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst()){nome.setText(it.getString(0));tel.setText(it.getString(1));obs.setText(it.getString(2))}}
        root.addView(nome); root.addView(tel); root.addView(obs)
        root.addView(button("💾 Salvar"){
            val v=ContentValues(); v.put("nome",nome.text.toString());v.put("telefone",tel.text.toString());v.put("observacoes",obs.text.toString())
            if(id==null) db.writableDatabase.insert("fornecedores",null,v) else db.writableDatabase.update("fornecedores",v,"id=?",arrayOf(id.toString()))
            showFornecedores()
        })
        root.addView(button("← Voltar"){showFornecedores()}); setContentView(root)
    }

    fun deleteFornecedor(id:Int){ db.writableDatabase.delete("fornecedores","id=?",arrayOf(id.toString())); showFornecedores() }

    fun showServidores() {
        val root=base("Servidores")
        content.addView(button("➕ Cadastrar servidor"){formServidor(null)})
        val c=db.readableDatabase.rawQuery("SELECT id,nome,valor FROM servidores ORDER BY nome",null)
        while(c.moveToNext()){
            val id=c.getInt(0); content.addView(label(c.getString(1)+" — R$ "+String.format("%.2f",c.getDouble(2))))
            content.addView(button("✏️ Editar"){formServidor(id)})
            content.addView(button("🗑️ Excluir"){db.writableDatabase.delete("servidores","id=?",arrayOf(id.toString()));showServidores()})
        }
        c.close(); content.addView(button("← Voltar"){showHome()}); setContentView(root)
    }

    fun formServidor(id:Int?) {
        val root=base(if(id==null)"Novo servidor" else "Editar servidor")
        val nome=EditText(this);nome.hint="Nome do servidor"
        val end=EditText(this);end.hint="Endereço / domínio"
        val usu=EditText(this);usu.hint="Usuário"
        val sen=EditText(this);sen.hint="Senha"
        val valr=EditText(this);valr.hint="Valor";valr.inputType=2
        val obs=EditText(this);obs.hint="Observações"
        if(id!=null) db.readableDatabase.rawQuery("SELECT nome,endereco,usuario,senha,valor,observacoes FROM servidores WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst()){nome.setText(it.getString(0));end.setText(it.getString(1));usu.setText(it.getString(2));sen.setText(it.getString(3));valr.setText(it.getDouble(4).toString());obs.setText(it.getString(5))}}
        listOf(nome,end,usu,sen,valr,obs).forEach{root.addView(it)}
        root.addView(button("💾 Salvar"){
            val v=ContentValues();v.put("nome",nome.text.toString());v.put("endereco",end.text.toString());v.put("usuario",usu.text.toString());v.put("senha",sen.text.toString());v.put("valor",valr.text.toString().replace(",",".").toDoubleOrNull()?:0.0);v.put("observacoes",obs.text.toString())
            if(id==null)db.writableDatabase.insert("servidores",null,v) else db.writableDatabase.update("servidores",v,"id=?",arrayOf(id.toString()))
            showServidores()
        })
        root.addView(button("← Voltar"){showServidores()});setContentView(root)
    }

    fun showResumo(){
        val root=base("Resumo financeiro")
        db.readableDatabase.rawQuery("SELECT COALESCE(SUM(valor),0) FROM servidores",null).use{it.moveToFirst();root.addView(label("Valor total dos servidores: R$ "+String.format("%.2f",it.getDouble(0))))}
        root.addView(button("← Voltar"){showHome()});setContentView(root)
    }

    fun backup(){
        Toast.makeText(this,"Backup local preparado. Para exportar o arquivo, use a função de compartilhamento na próxima versão.",Toast.LENGTH_LONG).show()
    }
}
